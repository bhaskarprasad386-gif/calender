# strategies/base_strategy.py
"""
Base class for future Algo Trading strategies (Phase 4).
Do not implement real strategies yet – only interface.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import pandas as pd


class BaseStrategy(ABC):
    def __init__(self, name: str = "BaseStrategy"):
        self.name = name
        self.enabled = False
        self.params: Dict[str, Any] = {}

    @abstractmethod
    def on_candle(self, candle: pd.Series, gap_df: pd.DataFrame) -> Optional[Dict[str, Any]]:
        """
        Called on every new candle (replay or live).
        Return signal dict or None.
        Example signal:
        {
            "action": "ENTRY",          # ENTRY / EXIT
            "side_curr": "BUY",
            "side_next": "SELL",
            "reason": "Gap extreme high"
        }
        """
        pass

    def on_start(self):
        self.enabled = True

    def on_stop(self):
        self.enabled = False


class PlaceholderCalendarStrategy(BaseStrategy):
    """Example placeholder – replace with real logic later."""

    def __init__(self):
        super().__init__(name="PlaceholderCalendar")
        self.params = {"zscore_threshold": 1.5, "lookback": 50}

    def on_candle(self, candle: pd.Series, gap_df: pd.DataFrame) -> Optional[Dict[str, Any]]:
        # Future: implement real gap mean-reversion / momentum logic here
        return None
