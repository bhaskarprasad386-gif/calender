# ui/login_window.py
import customtkinter as ctk
from typing import Callable, Optional


class LoginWindow(ctk.CTkToplevel):
    def __init__(self, master, on_login_success: Callable):
        super().__init__(master)
        self.on_login_success = on_login_success
        self.title("Angel One Login")
        self.geometry("420x480")
        self.resizable(False, False)
        self.grab_set()

        self._build()

    def _build(self):
        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=30, pady=30)

        ctk.CTkLabel(frame, text="Angel One SmartAPI", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=(10, 20))

        self.api_key = self._add_entry(frame, "API Key")
        self.client_code = self._add_entry(frame, "Client Code")
        self.password = self._add_entry(frame, "Password", show="*")
        self.totp_secret = self._add_entry(frame, "TOTP Secret")

        self.status_label = ctk.CTkLabel(frame, text="", text_color="gray")
        self.status_label.pack(pady=8)

        self.login_btn = ctk.CTkButton(frame, text="Login", command=self._on_login, height=40)
        self.login_btn.pack(fill="x", pady=10)

        ctk.CTkLabel(
            frame,
            text="Paper Trading mode – no real orders will be placed",
            font=ctk.CTkFont(size=12),
            text_color="gray",
        ).pack(pady=5)

        # Demo mode button
        ctk.CTkButton(
            frame,
            text="Continue in Demo Mode (No Login)",
            command=self._demo_mode,
            fg_color="gray30",
            height=36,
        ).pack(fill="x", pady=8)

    def _add_entry(self, parent, label: str, show: Optional[str] = None):
        ctk.CTkLabel(parent, text=label, anchor="w").pack(fill="x", pady=(8, 0))
        entry = ctk.CTkEntry(parent, show=show, height=36)
        entry.pack(fill="x", pady=2)
        return entry

    def _on_login(self):
        api_key = self.api_key.get().strip()
        client = self.client_code.get().strip()
        password = self.password.get().strip()
        totp = self.totp_secret.get().strip()

        if not all([api_key, client, password, totp]):
            self.status_label.configure(text="All fields required", text_color="red")
            return

        self.status_label.configure(text="Logging in...", text_color="yellow")
        self.login_btn.configure(state="disabled")
        self.update()

        from core.angel_api import AngelAPI
        api = AngelAPI(api_key, client, password, totp)
        result = api.login()

        if result.get("status"):
            self.status_label.configure(text="Login successful!", text_color="green")
            self.after(500, lambda: self._success(api))
        else:
            self.status_label.configure(text=result.get("message", "Login failed"), text_color="red")
            self.login_btn.configure(state="normal")

    def _demo_mode(self):
        self.on_login_success(None)  # None = demo mode
        self.destroy()

    def _success(self, api):
        self.on_login_success(api)
        self.destroy()
