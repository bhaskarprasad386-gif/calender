# ui/live_frame.py
import customtkinter as ctk
from datetime import datetime
from tkinter import messagebox
from typing import Optional, Any
from core.paper_trading import PaperTrading
from core.data_engine import OneSecondRecorder
from core.performance import calculate_performance
from config import SYMBOLS, DEFAULT_SPREAD_POINTS


class LiveFrame(ctk.CTkFrame):
    def __init__(self, master, angel_api: Optional[Any] = None, **kwargs):
        super().__init__(master, **kwargs)
        self.api = angel_api
        self.paper = PaperTrading()
        self.recorder = None
        self.symbol = "NIFTY"
        self.demo_curr = 24500.0
        self.demo_next = 24620.0
        self.demo_spread = DEFAULT_SPREAD_POINTS
        self._demo_job = None
        self._build()

    def _build(self):
        header = ctk.CTkFrame(self)
        header.pack(fill="x", padx=10, pady=8)
        ctk.CTkLabel(header, text="Live Paper Trading (Bid/Ask)", font=ctk.CTkFont(size=18, weight="bold")).pack(side="left", padx=8)

        self.symbol_var = ctk.StringVar(value="NIFTY")
        ctk.CTkOptionMenu(header, variable=self.symbol_var, values=list(SYMBOLS.keys()),
                          command=self._on_symbol_change, width=120).pack(side="left", padx=8)

        self.mode_label = ctk.CTkLabel(header, text="Mode: DEMO", text_color="orange")
        self.mode_label.pack(side="left", padx=12)
        if self.api and getattr(self.api, "logged_in", False):
            self.mode_label.configure(text="Mode: ANGEL LIVE", text_color="green")

        price = ctk.CTkFrame(self)
        price.pack(fill="x", padx=10, pady=6)
        self.lbl_curr = ctk.CTkLabel(price, text="Curr Bid/Ask: -", font=ctk.CTkFont(size=14))
        self.lbl_curr.pack(side="left", padx=10)
        self.lbl_next = ctk.CTkLabel(price, text="Next Bid/Ask: -", font=ctk.CTkFont(size=14))
        self.lbl_next.pack(side="left", padx=10)
        self.lbl_gap = ctk.CTkLabel(price, text="Gap: -", font=ctk.CTkFont(size=16, weight="bold"))
        self.lbl_gap.pack(side="left", padx=10)
        self.lbl_balance = ctk.CTkLabel(price, text="Balance: 0.00", font=ctk.CTkFont(size=14))
        self.lbl_balance.pack(side="right", padx=15)

        rec = ctk.CTkFrame(self)
        rec.pack(fill="x", padx=10, pady=6)
        self.rec_btn = ctk.CTkButton(rec, text="Start 1-Sec Recording", command=self._toggle_record, width=180)
        self.rec_btn.pack(side="left", padx=6)
        self.rec_status = ctk.CTkLabel(rec, text="Recording: OFF", text_color="gray")
        self.rec_status.pack(side="left", padx=8)
        ctk.CTkButton(rec, text="Start Demo Feed", command=self._start_demo_feed, width=130).pack(side="left", padx=6)
        ctk.CTkButton(rec, text="Stop Demo Feed", command=self._stop_demo_feed, width=130).pack(side="left", padx=6)

        trade = ctk.CTkFrame(self)
        trade.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(trade, text="Long Calendar (Buy Curr@Ask / Sell Next@Bid)",
                      command=lambda: self._open("BUY", "SELL"), fg_color="#1a7a3a", width=300, height=40).pack(side="left", padx=8)
        ctk.CTkButton(trade, text="Short Calendar (Sell Curr@Bid / Buy Next@Ask)",
                      command=lambda: self._open("SELL", "BUY"), fg_color="#8b1a1a", width=300, height=40).pack(side="left", padx=8)
        ctk.CTkButton(trade, text="Close All", command=self._close_all, width=100, height=40).pack(side="left", padx=8)

        ctk.CTkLabel(self, text="Open Positions", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=14, pady=(8, 0))
        self.open_box = ctk.CTkTextbox(self, height=100)
        self.open_box.pack(fill="x", padx=10, pady=4)

        ctk.CTkLabel(self, text="Trade Log / Closed", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=14, pady=(8, 0))
        self.log_box = ctk.CTkTextbox(self, height=200)
        self.log_box.pack(fill="both", expand=True, padx=10, pady=6)

    def _bids_asks(self):
        half = self.demo_spread / 2
        return (
            self.demo_curr - half, self.demo_curr + half,
            self.demo_next - half, self.demo_next + half,
        )

    def _on_symbol_change(self, value):
        self.symbol = value
        if value == "BANKNIFTY":
            self.demo_curr, self.demo_next = 52000.0, 52150.0
        else:
            self.demo_curr, self.demo_next = 24500.0, 24620.0
        self._update_prices()

    def _update_prices(self):
        cb, ca, nb, na = self._bids_asks()
        gap = ((nb + na) / 2) - ((cb + ca) / 2)
        gap_long = nb - ca
        gap_short = cb - na
        self.lbl_curr.configure(text=f"Curr Bid/Ask: {cb:.2f} / {ca:.2f}")
        self.lbl_next.configure(text=f"Next Bid/Ask: {nb:.2f} / {na:.2f}")
        self.lbl_gap.configure(text=f"Gap: {gap:.2f} | Long: {gap_long:.2f} | Short: {gap_short:.2f}")
        self.lbl_balance.configure(text=f"Balance: {self.paper.get_balance():.2f}")
        if self.recorder and self.recorder.recording:
            self.recorder.add_tick(datetime.now(), cb, ca, nb, na)

    def _toggle_record(self):
        if self.recorder and self.recorder.recording:
            path = self.recorder.stop()
            self.rec_btn.configure(text="Start 1-Sec Recording")
            self.rec_status.configure(text="Recording: OFF", text_color="gray")
            if path:
                self._log(f"1-sec session saved → {path}")
                messagebox.showinfo("Saved", f"Session saved:\n{path}")
        else:
            self.recorder = OneSecondRecorder(self.symbol)
            self.recorder.start()
            self.rec_btn.configure(text="Stop 1-Sec Recording")
            self.rec_status.configure(text="Recording: ON", text_color="red")
            self._log(f"Started 1-sec recording for {self.symbol}")

    def _start_demo_feed(self):
        self._stop_demo_feed()
        self._demo_tick()

    def _demo_tick(self):
        import random
        self.demo_curr += random.uniform(-3, 3)
        self.demo_next += random.uniform(-3.5, 3.5)
        self.demo_spread = abs(random.uniform(0.4, 1.5))
        self._update_prices()
        self._demo_job = self.after(1000, self._demo_tick)

    def _stop_demo_feed(self):
        if self._demo_job:
            self.after_cancel(self._demo_job)
            self._demo_job = None

    def _open(self, side_c: str, side_n: str):
        cb, ca, nb, na = self._bids_asks()
        gap = ((nb + na) / 2) - ((cb + ca) / 2)
        pos = self.paper.open_position(self.symbol, side_c, side_n, cb, ca, nb, na, qty=1, gap=gap)
        self._log(f"OPEN #{pos['id']} | {side_c}/{side_n} | Curr@{pos['curr_entry']:.2f} Next@{pos['next_entry']:.2f} Gap={gap:.2f}")
        self._refresh_open()

    def _close_all(self):
        cb, ca, nb, na = self._bids_asks()
        gap = ((nb + na) / 2) - ((cb + ca) / 2)
        for pid in [p["id"] for p in self.paper.get_open_positions()]:
            closed = self.paper.close_position(pid, cb, ca, nb, na, gap)
            if closed:
                self._log(f"CLOSE #{closed['id']} | PnL={closed['total_pnl']:.2f} (Curr={closed['curr_pnl']:.2f} Next={closed['next_pnl']:.2f} Cost={closed['cost']:.2f})")
        self._refresh_open()
        stats = calculate_performance(self.paper.get_closed_positions())
        self._log(f"STATS → {stats}")
        self.lbl_balance.configure(text=f"Balance: {self.paper.get_balance():.2f}")

    def _refresh_open(self):
        self.open_box.delete("1.0", "end")
        for p in self.paper.get_open_positions():
            self.open_box.insert("end", f"#{p['id']} {p['symbol']} {p['side_curr']}/{p['side_next']} @ {p['curr_entry']:.2f}/{p['next_entry']:.2f} | {p['entry_time']}\n")

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_box.insert("end", f"[{ts}] {msg}\n")
        self.log_box.see("end")

    def set_api(self, api):
        self.api = api
        if api and getattr(api, "logged_in", False):
            self.mode_label.configure(text="Mode: ANGEL LIVE", text_color="green")
        else:
            self.mode_label.configure(text="Mode: DEMO", text_color="orange")
