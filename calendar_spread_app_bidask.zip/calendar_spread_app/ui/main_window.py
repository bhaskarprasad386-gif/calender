# ui/main_window.py
import customtkinter as ctk
from typing import Optional, Any

from ui.replay_frame import ReplayFrame
from ui.live_frame import LiveFrame
from config import THEME, COLOR_THEME


class MainWindow(ctk.CTk):
    def __init__(self, angel_api: Optional[Any] = None):
        super().__init__()
        self.api = angel_api

        ctk.set_appearance_mode(THEME)
        ctk.set_default_color_theme(COLOR_THEME)

        self.title("Calendar Spread Desk – Angel One | Paper + Replay")
        self.geometry("1200x780")
        self.minsize(1000, 650)

        self._build()

    def _build(self):
        # Top bar
        top = ctk.CTkFrame(self, height=50)
        top.pack(fill="x", padx=8, pady=6)
        top.pack_propagate(False)

        ctk.CTkLabel(
            top, text="📅 Calendar Spread Desk",
            font=ctk.CTkFont(size=18, weight="bold")
        ).pack(side="left", padx=12)

        status = "Angel Connected" if (self.api and getattr(self.api, "logged_in", False)) else "Demo Mode"
        color = "green" if "Connected" in status else "orange"
        self.status_lbl = ctk.CTkLabel(top, text=status, text_color=color)
        self.status_lbl.pack(side="right", padx=12)

        # Tabs
        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=4)

        self.tabs.add("Replay (1-min)")
        self.tabs.add("Live Paper Trading")
        self.tabs.add("About / Algo Ready")

        # Replay tab
        self.replay_frame = ReplayFrame(self.tabs.tab("Replay (1-min)"))
        self.replay_frame.pack(fill="both", expand=True)

        # Live tab
        self.live_frame = LiveFrame(self.tabs.tab("Live Paper Trading"), angel_api=self.api)
        self.live_frame.pack(fill="both", expand=True)

        # About tab
        about = self.tabs.tab("About / Algo Ready")
        about_text = ctk.CTkTextbox(about)
        about_text.pack(fill="both", expand=True, padx=10, pady=10)
        about_text.insert("1.0", """
Calendar Spread Desk – Final Project

PHASES COMPLETED
----------------
✓ Phase 1 : Native Desktop App (CustomTkinter)
✓ Phase 2 : 1-minute Historical Replay + Gap Analysis + Timeframe switch
✓ Phase 3 : Live Paper Trading + 1-second data recording

ARCHITECTURE READY FOR
----------------------
→ Phase 4 : Algo Trading (strategies/base_strategy.py already present)
→ Phase 5 : Real Order Execution via Angel One

HOW TO USE
----------
1. Replay Tab
   - Create Sample Data  OR  Load your Current + Next Future 1-min CSV
   - Change timeframe (1m / 5m / 10m / 15m / 30m)
   - Step through candles and practice calendar entries

2. Live Paper Trading Tab
   - Start Demo Feed (simulates 1-sec ticks)  OR  connect Angel One
   - Start 1-Sec Recording → data saved in sessions/ folder
   - Open Long / Short Calendar positions
   - Close All → see P&L with brokerage + slippage

CSV FORMAT (1-min)
------------------
datetime,open,high,low,close,volume,oi
2025-06-02 09:15:00,24500,24510,24490,24505,1200,1500000

FUTURE ALGO
-----------
Put your strategy class in strategies/ folder inheriting BaseStrategy.
The engine will call on_candle() automatically in later versions.

""")
        about_text.configure(state="disabled")
