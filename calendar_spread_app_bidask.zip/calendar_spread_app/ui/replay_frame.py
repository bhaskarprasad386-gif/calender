# ui/replay_frame.py
import customtkinter as ctk
from tkinter import filedialog, messagebox
from core.data_engine import load_pair, create_sample_data
from core.replay_engine import CalendarReplayEngine
from core.performance import calculate_performance
from config import TIMEFRAMES, SAMPLE_DIR


class ReplayFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.engine = None
        self._build()

    def _build(self):
        top = ctk.CTkFrame(self)
        top.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(top, text="Create Sample Data", command=self._create_sample, width=140).pack(side="left", padx=4)
        ctk.CTkButton(top, text="Load Current CSV", command=self._load_curr, width=130).pack(side="left", padx=4)
        ctk.CTkButton(top, text="Load Next CSV", command=self._load_next, width=120).pack(side="left", padx=4)
        ctk.CTkButton(top, text="Load Pair", command=self._load_pair, width=100).pack(side="left", padx=4)

        self.tf_var = ctk.StringVar(value="1min")
        ctk.CTkOptionMenu(top, variable=self.tf_var, values=list(TIMEFRAMES.keys()), width=90).pack(side="left", padx=8)
        ctk.CTkButton(top, text="Apply TF", command=self._apply_tf, width=80).pack(side="left", padx=4)

        self.curr_path = ctk.StringVar(value=str(SAMPLE_DIR / "NIFTY_current_1min.csv"))
        self.next_path = ctk.StringVar(value=str(SAMPLE_DIR / "NIFTY_next_1min.csv"))
        path_frame = ctk.CTkFrame(self)
        path_frame.pack(fill="x", padx=10, pady=4)
        ctk.CTkLabel(path_frame, text="Curr:").pack(side="left")
        ctk.CTkEntry(path_frame, textvariable=self.curr_path, width=360).pack(side="left", padx=4)
        ctk.CTkLabel(path_frame, text="Next:").pack(side="left", padx=(10, 0))
        ctk.CTkEntry(path_frame, textvariable=self.next_path, width=360).pack(side="left", padx=4)

        ctrl = ctk.CTkFrame(self)
        ctrl.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(ctrl, text="Reset", command=self._reset, width=80).pack(side="left", padx=3)
        ctk.CTkButton(ctrl, text="Step +1", command=lambda: self._step(1), width=80).pack(side="left", padx=3)
        ctk.CTkButton(ctrl, text="Step +5", command=lambda: self._step(5), width=80).pack(side="left", padx=3)
        ctk.CTkButton(ctrl, text="Step +20", command=lambda: self._step(20), width=80).pack(side="left", padx=3)
        ctk.CTkButton(ctrl, text="Step +100", command=lambda: self._step(100), width=90).pack(side="left", padx=3)
        self.progress = ctk.CTkProgressBar(ctrl, width=200)
        self.progress.pack(side="left", padx=12)
        self.progress.set(0)
        self.progress_label = ctk.CTkLabel(ctrl, text="0%")
        self.progress_label.pack(side="left")

        info = ctk.CTkFrame(self)
        info.pack(fill="x", padx=10, pady=6)
        self.lbl_time = ctk.CTkLabel(info, text="Time: -", font=ctk.CTkFont(size=13))
        self.lbl_time.pack(side="left", padx=8)
        self.lbl_gap = ctk.CTkLabel(info, text="Gap: -", font=ctk.CTkFont(size=13, weight="bold"))
        self.lbl_gap.pack(side="left", padx=8)
        self.lbl_ba = ctk.CTkLabel(info, text="Bid/Ask: -")
        self.lbl_ba.pack(side="left", padx=8)

        trade = ctk.CTkFrame(self)
        trade.pack(fill="x", padx=10, pady=6)
        ctk.CTkButton(trade, text="Long Calendar (Buy@Ask / Sell@Bid)",
                      command=lambda: self._enter("BUY", "SELL"), fg_color="#1a7a3a", width=260).pack(side="left", padx=6)
        ctk.CTkButton(trade, text="Short Calendar (Sell@Bid / Buy@Ask)",
                      command=lambda: self._enter("SELL", "BUY"), fg_color="#8b1a1a", width=260).pack(side="left", padx=6)
        ctk.CTkButton(trade, text="Exit Trade", command=self._exit, width=100).pack(side="left", padx=6)

        self.result_box = ctk.CTkTextbox(self, height=220)
        self.result_box.pack(fill="both", expand=True, padx=10, pady=8)

    def _create_sample(self):
        try:
            curr, nxt = create_sample_data("NIFTY", days=5)
            self.curr_path.set(str(curr))
            self.next_path.set(str(nxt))
            messagebox.showinfo("Sample Data", f"Created with Bid/Ask:\n{curr}\n{nxt}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _load_curr(self):
        p = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if p:
            self.curr_path.set(p)

    def _load_next(self):
        p = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if p:
            self.next_path.set(p)

    def _load_pair(self):
        try:
            curr_df, next_df = load_pair(self.curr_path.get(), self.next_path.get())
            self.engine = CalendarReplayEngine(curr_df, next_df)
            self.engine.set_timeframe(self.tf_var.get())
            self._update_ui()
            self._log(f"Loaded {self.engine.total_candles()} candles | TF={self.tf_var.get()} | Bid/Ask enabled")
        except Exception as e:
            messagebox.showerror("Load Error", str(e))

    def _apply_tf(self):
        if not self.engine:
            return
        self.engine.set_timeframe(self.tf_var.get())
        self._update_ui()
        self._log(f"Timeframe → {self.tf_var.get()} | Candles: {self.engine.total_candles()}")

    def _reset(self):
        if self.engine:
            self.engine.reset()
            self._update_ui()

    def _step(self, n: int):
        if self.engine:
            self.engine.step(n)
            self._update_ui()

    def _enter(self, side_c: str, side_n: str):
        if not self.engine:
            return
        try:
            t = self.engine.enter_trade(side_c, side_n, qty=1)
            self._log(f"ENTRY {side_c}/{side_n} | Gap={t['entry_gap']:.2f} Long={t.get('gap_long',0):.2f} | Fill Curr={t['curr_entry']:.2f} Next={t['next_entry']:.2f}")
        except Exception as e:
            messagebox.showerror("Entry Error", str(e))

    def _exit(self):
        if not self.engine:
            return
        res = self.engine.exit_trade()
        if res:
            self._log(f"EXIT PnL={res['total_pnl']:.2f} (C={res['curr_pnl']:.2f} N={res['next_pnl']:.2f}) | Gap {res['entry_gap']:.2f}→{res['exit_gap']:.2f}")
            self._log(f"STATS | {calculate_performance(self.engine.closed_trades)}")
        else:
            self._log("No open position")

    def _update_ui(self):
        if not self.engine:
            return
        c = self.engine.get_current_candle()
        prog = self.engine.get_progress()
        self.progress.set(prog / 100.0)
        self.progress_label.configure(text=f"{prog:.1f}%")
        if c is not None:
            self.lbl_time.configure(text=f"Time: {c['datetime']}")
            gl = c.get("gap_long", 0)
            gs = c.get("gap_short", 0)
            self.lbl_gap.configure(text=f"Gap: {c['gap']:.2f} | L:{gl:.2f} S:{gs:.2f}")
            self.lbl_ba.configure(
                text=f"Curr {c['bid_curr']:.2f}/{c['ask_curr']:.2f}  Next {c['bid_next']:.2f}/{c['ask_next']:.2f}"
            )

    def _log(self, msg: str):
        self.result_box.insert("end", msg + "\n")
        self.result_box.see("end")
