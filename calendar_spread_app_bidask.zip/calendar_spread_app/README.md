# Calendar Spread Desk

Native Desktop App for NSE Calendar Spread (Current vs Next Future) with **Bid/Ask** support.

## Features

- **1-minute Historical Replay** (1m / 5m / 10m / 15m / 30m)
- **Bid/Ask aware** gap & fills
  - Buy @ Ask, Sell @ Bid
  - `gap` (mid), `gap_long`, `gap_short`
- **Live Paper Trading** + 1-second data recording
- Angel One SmartAPI login (optional)
- Brokerage + Slippage simulation
- Performance stats
- Algo-ready (`strategies/base_strategy.py`)

## Install

```bash
cd calendar_spread_app
pip install -r requirements.txt
python main.py
```

## CSV Format (with Bid/Ask)

```
datetime,open,high,low,close,volume,oi,bid,ask
2025-06-02 09:15:00,24500,24510,24490,24505,1200,1500000,24504.5,24505.5
```

If `bid`/`ask` missing, app approximates from close using `DEFAULT_SPREAD_POINTS`.

## GitHub Upload

1. Create new repo on GitHub
2. Upload this folder (or push via git)
3. Clone on any machine and run

## Structure

```
calendar_spread_app/
├── main.py
├── config.py
├── requirements.txt
├── core/          # engines
├── ui/            # CustomTkinter GUI
├── strategies/    # Phase 4 algo
├── data/sample/
└── sessions/
```
