# config.py
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
SAMPLE_DIR = DATA_DIR / "sample"
SESSION_DIR = BASE_DIR / "sessions"
SESSION_DIR.mkdir(parents=True, exist_ok=True)
SAMPLE_DIR.mkdir(parents=True, exist_ok=True)

SYMBOLS = {
    "NIFTY": {
        "name": "NIFTY",
        "lot_size": 25,
        "exchange": "NFO",
        "instrumenttype": "FUTIDX",
    },
    "BANKNIFTY": {
        "name": "BANKNIFTY",
        "lot_size": 15,
        "exchange": "NFO",
        "instrumenttype": "FUTIDX",
    },
}

TIMEFRAMES = {
    "1min": "1minute",
    "5min": "5minute",
    "10min": "10minute",
    "15min": "15minute",
    "30min": "30minute",
}

DEFAULT_BROKERAGE_PER_LOT = 40.0
DEFAULT_SLIPPAGE_POINTS = 0.5
DEFAULT_SPREAD_POINTS = 0.5

THEME = "dark"
COLOR_THEME = "blue"
