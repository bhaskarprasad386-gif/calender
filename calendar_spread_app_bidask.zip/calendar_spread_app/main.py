# main.py
"""
Calendar Spread Desk – Entry Point
Native Desktop App with Angel One support
"""

import customtkinter as ctk
from ui.login_window import LoginWindow
from ui.main_window import MainWindow
from config import THEME, COLOR_THEME


def main():
    ctk.set_appearance_mode(THEME)
    ctk.set_default_color_theme(COLOR_THEME)

    # Hidden root for login dialog
    root = ctk.CTk()
    root.withdraw()

    def on_login(api):
        root.destroy()
        app = MainWindow(angel_api=api)
        app.mainloop()

    login = LoginWindow(root, on_login_success=on_login)
    root.mainloop()


if __name__ == "__main__":
    main()
