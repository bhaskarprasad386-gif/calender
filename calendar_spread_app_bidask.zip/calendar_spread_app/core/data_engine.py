# core/data_engine.py
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import Tuple
from config import SAMPLE_DIR, SESSION_DIR, DEFAULT_SPREAD_POINTS


def load_csv(filepath: str | Path) -> pd.DataFrame:
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    df = pd.read_csv(path)
    if "datetime" in df.columns:
        df["datetime"] = pd.to_datetime(df["datetime"])
    elif "date" in df.columns and "time" in df.columns:
        df["datetime"] = pd.to_datetime(df["date"].astype(str) + " " + df["time"].astype(str))
    else:
        raise ValueError("CSV must have 'datetime' or 'date'+'time' columns")

    for col in ("open", "high", "low", "close"):
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    if "volume" not in df.columns:
        df["volume"] = 0
    if "oi" not in df.columns:
        df["oi"] = 0

    # Bid/Ask: use columns if present, else approximate from close
    half = DEFAULT_SPREAD_POINTS / 2.0
    if "bid" not in df.columns:
        df["bid"] = df["close"] - half
    if "ask" not in df.columns:
        df["ask"] = df["close"] + half

    return df.sort_values("datetime").reset_index(drop=True)


def load_pair(curr_path: str | Path, next_path: str | Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    return load_csv(curr_path), load_csv(next_path)


def create_sample_data(symbol: str = "NIFTY", days: int = 5) -> Tuple[Path, Path]:
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    start = datetime(2025, 6, 2, 9, 15)
    rows_curr = []
    price_curr = 24500.0 if symbol == "NIFTY" else 52000.0

    for d in range(days):
        day_start = start + timedelta(days=d)
        if day_start.weekday() >= 5:
            continue
        for m in range(375):
            dt = day_start + timedelta(minutes=m)
            noise = np.random.randn() * 4
            price_curr += noise
            spread = abs(np.random.uniform(0.4, 1.5))
            high_c = price_curr + abs(np.random.randn() * 3)
            low_c = price_curr - abs(np.random.randn() * 3)
            rows_curr.append({
                "datetime": dt,
                "open": round(price_curr, 2),
                "high": round(high_c, 2),
                "low": round(low_c, 2),
                "close": round(price_curr, 2),
                "volume": int(np.random.randint(80, 600)),
                "oi": int(1_200_000 + np.random.randint(-8000, 8000)),
                "bid": round(price_curr - spread / 2, 2),
                "ask": round(price_curr + spread / 2, 2),
            })

    df_curr = pd.DataFrame(rows_curr)
    df_next = df_curr.copy()
    base_spread = 120 + np.random.randn(len(df_next)) * 3
    for col in ("open", "high", "low", "close", "bid", "ask"):
        df_next[col] = (df_next[col] + base_spread).round(2)

    curr_path = SAMPLE_DIR / f"{symbol}_current_1min.csv"
    next_path = SAMPLE_DIR / f"{symbol}_next_1min.csv"
    df_curr.to_csv(curr_path, index=False)
    df_next.to_csv(next_path, index=False)
    return curr_path, next_path


class OneSecondRecorder:
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.rows = []
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filepath = SESSION_DIR / f"{symbol}_{self.session_id}_1sec.parquet"
        self.recording = False

    def start(self):
        self.rows = []
        self.recording = True

    def stop(self):
        self.recording = False
        if self.rows:
            df = pd.DataFrame(self.rows)
            df.to_parquet(self.filepath, index=False)
            return self.filepath
        return None

    def add_tick(self, dt: datetime,
                 curr_bid: float, curr_ask: float,
                 next_bid: float, next_ask: float,
                 curr_oi: int = 0, next_oi: int = 0):
        if not self.recording:
            return
        mid_c = (curr_bid + curr_ask) / 2
        mid_n = (next_bid + next_ask) / 2
        self.rows.append({
            "datetime": dt,
            "close_curr": mid_c, "close_next": mid_n,
            "open_curr": mid_c, "high_curr": mid_c, "low_curr": mid_c,
            "open_next": mid_n, "high_next": mid_n, "low_next": mid_n,
            "bid_curr": curr_bid, "ask_curr": curr_ask,
            "bid_next": next_bid, "ask_next": next_ask,
            "volume": 0, "oi_curr": curr_oi, "oi_next": next_oi,
            "gap": mid_n - mid_c,
            "gap_long": next_bid - curr_ask,
            "gap_short": curr_bid - next_ask,
        })

    def save_partial(self):
        if self.rows:
            pd.DataFrame(self.rows).to_parquet(self.filepath, index=False)
