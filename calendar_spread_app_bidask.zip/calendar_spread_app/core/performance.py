# core/performance.py
import pandas as pd
import numpy as np
from typing import List, Dict, Any


def calculate_performance(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not trades:
        return {
            "Total Trades": 0,
            "Win Rate %": 0.0,
            "Net P&L": 0.0,
            "Average Win": 0.0,
            "Average Loss": 0.0,
            "Profit Factor": 0.0,
            "Max Drawdown": 0.0,
            "Best Trade": 0.0,
            "Worst Trade": 0.0,
        }

    df = pd.DataFrame(trades)
    if "total_pnl" not in df.columns:
        return {}

    pnls = df["total_pnl"].astype(float).values
    wins = pnls[pnls > 0]
    losses = pnls[pnls < 0]

    total_trades = len(pnls)
    win_rate = (len(wins) / total_trades * 100) if total_trades else 0.0
    avg_win = float(wins.mean()) if len(wins) else 0.0
    avg_loss = float(losses.mean()) if len(losses) else 0.0

    if len(losses) and losses.sum() != 0:
        profit_factor = abs(float(wins.sum() / losses.sum()))
    else:
        profit_factor = float("inf") if len(wins) else 0.0

    equity = np.cumsum(pnls)
    max_dd = 0.0
    peak = equity[0] if len(equity) else 0.0
    for x in equity:
        if x > peak:
            peak = x
        dd = peak - x
        if dd > max_dd:
            max_dd = dd

    return {
        "Total Trades": total_trades,
        "Win Rate %": round(win_rate, 2),
        "Net P&L": round(float(pnls.sum()), 2),
        "Average Win": round(avg_win, 2),
        "Average Loss": round(avg_loss, 2),
        "Profit Factor": round(profit_factor, 2) if profit_factor != float("inf") else "Inf",
        "Max Drawdown": round(float(max_dd), 2),
        "Best Trade": round(float(pnls.max()), 2) if len(pnls) else 0.0,
        "Worst Trade": round(float(pnls.min()), 2) if len(pnls) else 0.0,
    }
