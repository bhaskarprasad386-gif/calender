# core/resampler.py
import pandas as pd


def resample_ohlc(df: pd.DataFrame, timeframe: str = "5min") -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    df = df.copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.set_index("datetime").sort_index()

    rule_map = {
        "1min": "1min", "5min": "5min", "10min": "10min",
        "15min": "15min", "30min": "30min",
        "1minute": "1min", "5minute": "5min", "10minute": "10min",
        "15minute": "15min", "30minute": "30min",
    }
    rule = rule_map.get(timeframe, timeframe)

    agg = {
        "open": "first", "high": "max", "low": "min",
        "close": "last", "volume": "sum",
    }
    if "oi" in df.columns:
        agg["oi"] = "last"
    if "bid" in df.columns:
        agg["bid"] = "last"
    if "ask" in df.columns:
        agg["ask"] = "last"

    resampled = df.resample(rule).agg(agg).dropna(subset=["open", "high", "low", "close"])
    return resampled.reset_index()
