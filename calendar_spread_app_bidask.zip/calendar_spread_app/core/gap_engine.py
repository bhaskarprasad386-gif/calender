# core/gap_engine.py
import pandas as pd
import numpy as np
from config import DEFAULT_SPREAD_POINTS


def _ensure_bid_ask(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "bid" not in df.columns or "ask" not in df.columns:
        half = DEFAULT_SPREAD_POINTS / 2.0
        if "close" in df.columns:
            df["bid"] = df["close"] - half
            df["ask"] = df["close"] + half
        else:
            df["bid"] = 0.0
            df["ask"] = 0.0
    return df


def calculate_gap(curr_df: pd.DataFrame, next_df: pd.DataFrame) -> pd.DataFrame:
    """
    gap       = mid_next - mid_curr
    gap_long  = bid_next - ask_curr   (Buy Curr @Ask, Sell Next @Bid)
    gap_short = bid_curr - ask_next   (Sell Curr @Bid, Buy Next @Ask)
    """
    if curr_df is None or next_df is None or curr_df.empty or next_df.empty:
        return pd.DataFrame()

    curr = _ensure_bid_ask(curr_df.copy())
    nxt = _ensure_bid_ask(next_df.copy())
    curr["datetime"] = pd.to_datetime(curr["datetime"])
    nxt["datetime"] = pd.to_datetime(nxt["datetime"])

    merged = pd.merge(curr, nxt, on="datetime", suffixes=("_curr", "_next"), how="inner")
    if merged.empty:
        return merged

    for side in ("_curr", "_next"):
        if f"bid{side}" not in merged.columns:
            half = DEFAULT_SPREAD_POINTS / 2.0
            merged[f"bid{side}"] = merged[f"close{side}"] - half
            merged[f"ask{side}"] = merged[f"close{side}"] + half

    merged["mid_curr"] = (merged["bid_curr"] + merged["ask_curr"]) / 2.0
    merged["mid_next"] = (merged["bid_next"] + merged["ask_next"]) / 2.0
    merged["gap"] = merged["mid_next"] - merged["mid_curr"]
    merged["gap_long"] = merged["bid_next"] - merged["ask_curr"]
    merged["gap_short"] = merged["bid_curr"] - merged["ask_next"]
    merged["gap_cummax"] = merged["gap"].cummax()
    merged["gap_cummin"] = merged["gap"].cummin()

    return merged.sort_values("datetime").reset_index(drop=True)


def daily_gap_summary(gap_df: pd.DataFrame) -> pd.DataFrame:
    if gap_df is None or gap_df.empty:
        return pd.DataFrame()
    df = gap_df.copy()
    df["date"] = pd.to_datetime(df["datetime"]).dt.date
    summary = df.groupby("date").agg(
        gap_open=("gap", "first"),
        gap_high=("gap", "max"),
        gap_low=("gap", "min"),
        gap_close=("gap", "last"),
        gap_mean=("gap", "mean"),
        gap_std=("gap", "std"),
    ).round(2).reset_index()
    return summary


def time_of_day_analysis(gap_df: pd.DataFrame) -> pd.DataFrame:
    if gap_df is None or gap_df.empty:
        return pd.DataFrame()
    df = gap_df.copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    df["minutes"] = df["datetime"].dt.hour * 60 + df["datetime"].dt.minute

    def session(m):
        if 9 * 60 + 15 <= m < 10 * 60 + 30:
            return "Morning (9:15-10:30)"
        elif 10 * 60 + 30 <= m < 14 * 60:
            return "Midday (10:30-14:00)"
        return "Afternoon (14:00-15:30)"

    df["session"] = df["minutes"].apply(session)
    return df.groupby("session").agg(
        avg_gap=("gap", "mean"), max_gap=("gap", "max"),
        min_gap=("gap", "min"), std_gap=("gap", "std"), count=("gap", "count"),
    ).round(2).reset_index()


def gap_extreme_alert(gap_series: pd.Series, lookback: int = 100, threshold: float = 1.5) -> dict:
    if gap_series is None or len(gap_series) < lookback:
        return {"alert": False}
    recent = gap_series.tail(lookback)
    mean, std = recent.mean(), recent.std()
    current = gap_series.iloc[-1]
    if std == 0 or np.isnan(std):
        return {"alert": False}
    zscore = (current - mean) / std
    if abs(zscore) >= threshold:
        return {
            "alert": True,
            "current_gap": round(float(current), 2),
            "zscore": round(float(zscore), 2),
            "message": "Gap Extremely High" if zscore > 0 else "Gap Extremely Low",
        }
    return {"alert": False}
