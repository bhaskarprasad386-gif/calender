# core/paper_trading.py
from datetime import datetime
from typing import List, Dict, Any, Optional
from config import DEFAULT_BROKERAGE_PER_LOT, DEFAULT_SLIPPAGE_POINTS


class PaperTrading:
    def __init__(self, brokerage_per_lot: float = DEFAULT_BROKERAGE_PER_LOT,
                 slippage_points: float = DEFAULT_SLIPPAGE_POINTS):
        self.open_positions: List[Dict[str, Any]] = []
        self.closed_positions: List[Dict[str, Any]] = []
        self.balance = 0.0
        self.brokerage_per_lot = brokerage_per_lot
        self.slippage_points = slippage_points
        self._id_counter = 0

    def _next_id(self) -> int:
        self._id_counter += 1
        return self._id_counter

    @staticmethod
    def _fill_price(side: str, bid: float, ask: float, is_entry: bool = True) -> float:
        side = side.upper()
        if is_entry:
            return float(ask) if side == "BUY" else float(bid)
        return float(bid) if side == "BUY" else float(ask)

    def open_position(self, symbol: str, side_curr: str, side_next: str,
                      curr_bid: float, curr_ask: float,
                      next_bid: float, next_ask: float,
                      qty: int = 1, gap: float = 0.0) -> Dict[str, Any]:
        curr_entry = self._fill_price(side_curr, curr_bid, curr_ask, True)
        next_entry = self._fill_price(side_next, next_bid, next_ask, True)
        pos = {
            "id": self._next_id(),
            "symbol": symbol,
            "side_curr": side_curr.upper(),
            "side_next": side_next.upper(),
            "curr_entry": curr_entry,
            "next_entry": next_entry,
            "entry_gap": float(gap),
            "qty": int(qty),
            "entry_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "OPEN",
        }
        self.open_positions.append(pos)
        return pos

    def close_position(self, pos_id: int,
                       curr_bid: float, curr_ask: float,
                       next_bid: float, next_ask: float,
                       gap: float = 0.0) -> Optional[Dict[str, Any]]:
        for i, pos in enumerate(self.open_positions):
            if pos["id"] != pos_id:
                continue
            curr_exit = self._fill_price(pos["side_curr"], curr_bid, curr_ask, False)
            next_exit = self._fill_price(pos["side_next"], next_bid, next_ask, False)
            if pos["side_curr"] == "BUY":
                curr_pnl = (curr_exit - pos["curr_entry"]) * pos["qty"]
            else:
                curr_pnl = (pos["curr_entry"] - curr_exit) * pos["qty"]
            if pos["side_next"] == "BUY":
                next_pnl = (next_exit - pos["next_entry"]) * pos["qty"]
            else:
                next_pnl = (pos["next_entry"] - next_exit) * pos["qty"]
            cost = (self.brokerage_per_lot * 2 * pos["qty"]) + (self.slippage_points * 2 * pos["qty"])
            total = round(curr_pnl + next_pnl - cost, 2)
            closed = {
                **pos,
                "curr_exit": curr_exit,
                "next_exit": next_exit,
                "exit_gap": float(gap),
                "exit_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "curr_pnl": round(curr_pnl, 2),
                "next_pnl": round(next_pnl, 2),
                "cost": round(cost, 2),
                "total_pnl": total,
                "status": "CLOSED",
            }
            self.closed_positions.append(closed)
            self.open_positions.pop(i)
            self.balance += total
            return closed
        return None

    def get_open_positions(self):
        return list(self.open_positions)

    def get_closed_positions(self):
        return list(self.closed_positions)

    def get_balance(self):
        return round(self.balance, 2)
