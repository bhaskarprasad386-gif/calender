# core/angel_api.py
"""
Angel One SmartAPI wrapper.
Requires: smartapi-python, pyotp

Usage:
    api = AngelAPI(api_key, client_code, password, totp_secret)
    api.login()
    # historical / websocket methods
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable
import threading
import time
import json

try:
    from SmartApi import SmartConnect
    from SmartApi.smartWebSocketV2 import SmartWebSocketV2
    import pyotp
    SMARTAPI_AVAILABLE = True
except ImportError:
    SMARTAPI_AVAILABLE = False
    SmartConnect = None
    SmartWebSocketV2 = None
    pyotp = None


class AngelAPI:
    def __init__(
        self,
        api_key: str,
        client_code: str,
        password: str,
        totp_secret: str,
    ):
        self.api_key = api_key
        self.client_code = client_code
        self.password = password
        self.totp_secret = totp_secret

        self.smart: Optional[Any] = None
        self.auth_token: Optional[str] = None
        self.feed_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.logged_in = False

        self.ws: Optional[Any] = None
        self.ws_thread: Optional[threading.Thread] = None
        self.tick_callback: Optional[Callable] = None
        self._subscribed_tokens: List[str] = []

    def login(self) -> Dict[str, Any]:
        if not SMARTAPI_AVAILABLE:
            return {
                "status": False,
                "message": "smartapi-python not installed. Run: pip install smartapi-python pyotp"
            }

        try:
            self.smart = SmartConnect(api_key=self.api_key)
            totp = pyotp.TOTP(self.totp_secret).now()
            data = self.smart.generateSession(self.client_code, self.password, totp)

            if data.get("status") is False:
                return {"status": False, "message": data.get("message", "Login failed")}

            self.auth_token = data["data"]["jwtToken"]
            self.refresh_token = data["data"]["refreshToken"]
            self.feed_token = self.smart.getfeedToken()
            self.logged_in = True
            return {"status": True, "message": "Login successful", "data": data.get("data")}
        except Exception as e:
            return {"status": False, "message": str(e)}

    def logout(self) -> None:
        try:
            if self.smart and self.logged_in:
                self.smart.terminateSession(self.client_code)
        except Exception:
            pass
        self.logged_in = False
        self.stop_websocket()

    def get_profile(self) -> Dict:
        if not self.logged_in:
            return {}
        try:
            return self.smart.getProfile(self.refresh_token)
        except Exception:
            return {}

    def search_scrip(self, exchange: str, searchtext: str) -> List[Dict]:
        if not self.logged_in:
            return []
        try:
            res = self.smart.searchScrip(exchange, searchtext)
            return res.get("data", []) if res else []
        except Exception:
            return []

    def get_historical(
        self,
        exchange: str,
        symboltoken: str,
        interval: str,
        from_date: str,
        to_date: str,
    ) -> List[List]:
        """
        interval examples: ONE_MINUTE, FIVE_MINUTE, FIFTEEN_MINUTE, ONE_DAY
        from_date / to_date format: '2025-06-01 09:15'
        Returns list of candles: [timestamp, open, high, low, close, volume]
        """
        if not self.logged_in:
            return []
        try:
            params = {
                "exchange": exchange,
                "symboltoken": symboltoken,
                "interval": interval,
                "fromdate": from_date,
                "todate": to_date,
            }
            res = self.smart.getCandleData(params)
            if res and res.get("status"):
                return res.get("data", [])
            return []
        except Exception as e:
            print(f"Historical error: {e}")
            return []

    def ltp_data(self, exchange: str, tradingsymbol: str, symboltoken: str) -> Dict:
        if not self.logged_in:
            return {}
        try:
            return self.smart.ltpData(exchange, tradingsymbol, symboltoken)
        except Exception:
            return {}

    # ─── WebSocket (Live 1-sec / tick) ───────────────────────────

    def start_websocket(self, on_tick: Callable, tokens: List[Dict] = None):
        """
        tokens example:
        [{"exchangeType": 2, "tokens": ["99926000"]}]   # NFO
        """
        if not self.logged_in or not SMARTAPI_AVAILABLE:
            return False

        self.tick_callback = on_tick
        self._subscribed_tokens = tokens or []

        try:
            self.ws = SmartWebSocketV2(
                self.auth_token,
                self.api_key,
                self.client_code,
                self.feed_token,
            )

            def on_data(wsapp, message):
                if self.tick_callback:
                    try:
                        self.tick_callback(message)
                    except Exception as e:
                        print(f"Tick callback error: {e}")

            def on_open(wsapp):
                print("WebSocket opened")
                if self._subscribed_tokens:
                    self.ws.subscribe("cs_sub", 1, self._subscribed_tokens)

            def on_error(wsapp, error):
                print(f"WebSocket error: {error}")

            def on_close(wsapp):
                print("WebSocket closed")

            self.ws.on_open = on_open
            self.ws.on_data = on_data
            self.ws.on_error = on_error
            self.ws.on_close = on_close

            self.ws_thread = threading.Thread(target=self.ws.connect, daemon=True)
            self.ws_thread.start()
            return True
        except Exception as e:
            print(f"WebSocket start error: {e}")
            return False

    def stop_websocket(self):
        try:
            if self.ws:
                self.ws.close_connection()
        except Exception:
            pass
        self.ws = None

    def subscribe(self, tokens: List[Dict]):
        """Subscribe additional tokens while WS is running."""
        self._subscribed_tokens = tokens
        if self.ws:
            try:
                self.ws.subscribe("cs_sub", 1, tokens)
            except Exception as e:
                print(f"Subscribe error: {e}")
