# core/replay_engine.py
import pandas as pd
from typing import Optional, Dict, Any, List
from core.resampler import resample_ohlc
from core.gap_engine import calculate_gap


class CalendarReplayEngine:
    def __init__(self, curr_df: pd.DataFrame, next_df: pd.DataFrame):
        self.original_curr = curr_df.copy() if curr_df is not None else pd.DataFrame()
        self.original_next = next_df.copy() if next_df is not None else pd.DataFrame()
        self.timeframe = "1min"
        self.gap_df = calculate_gap(self.original_curr, self.original_next)
        self.current_idx = 0
        self.positions: List[Dict[str, Any]] = []
        self.closed_trades: List[Dict[str, Any]] = []

    def set_timeframe(self, timeframe: str) -> None:
        if timeframe in ("1min", "1minute"):
            self.gap_df = calculate_gap(self.original_curr, self.original_next)
        else:
            curr_res = resample_ohlc(self.original_curr, timeframe)
            next_res = resample_ohlc(self.original_next, timeframe)
            self.gap_df = calculate_gap(curr_res, next_res)
        self.timeframe = timeframe
        self.current_idx = 0

    def reset(self) -> None:
        self.current_idx = 0
        self.positions = []
        self.closed_trades = []

    def get_current_candle(self) -> Optional[pd.Series]:
        if self.gap_df.empty or self.current_idx >= len(self.gap_df):
            return None
        return self.gap_df.iloc[self.current_idx]

    def step(self, n: int = 1) -> Optional[pd.Series]:
        if self.gap_df.empty:
            return None
        self.current_idx = min(self.current_idx + n, len(self.gap_df) - 1)
        return self.get_current_candle()

    def jump_to(self, idx: int) -> Optional[pd.Series]:
        if self.gap_df.empty:
            return None
        self.current_idx = max(0, min(idx, len(self.gap_df) - 1))
        return self.get_current_candle()

    def jump_to_datetime(self, target_time: str) -> Optional[pd.Series]:
        if self.gap_df.empty:
            return None
        target = pd.to_datetime(target_time)
        idx = self.gap_df["datetime"].searchsorted(target)
        self.current_idx = min(int(idx), len(self.gap_df) - 1)
        return self.get_current_candle()

    def enter_trade(self, side_curr: str, side_next: str, qty: int = 1) -> Dict[str, Any]:
        candle = self.get_current_candle()
        if candle is None:
            raise ValueError("No candle available for entry")

        # Fill at Bid/Ask
        curr_entry = float(candle["ask_curr"]) if side_curr.upper() == "BUY" else float(candle["bid_curr"])
        next_entry = float(candle["ask_next"]) if side_next.upper() == "BUY" else float(candle["bid_next"])

        trade = {
            "entry_idx": self.current_idx,
            "entry_time": str(candle["datetime"]),
            "entry_gap": float(candle["gap"]),
            "gap_long": float(candle.get("gap_long", 0)),
            "gap_short": float(candle.get("gap_short", 0)),
            "curr_entry": curr_entry,
            "next_entry": next_entry,
            "side_curr": side_curr.upper(),
            "side_next": side_next.upper(),
            "qty": int(qty),
        }
        self.positions.append(trade)
        return trade

    def exit_trade(self) -> Optional[Dict[str, Any]]:
        if not self.positions:
            return None
        candle = self.get_current_candle()
        if candle is None:
            return None

        trade = self.positions.pop()
        # Exit: reverse of entry (BUY closes at bid, SELL closes at ask)
        curr_exit = float(candle["bid_curr"]) if trade["side_curr"] == "BUY" else float(candle["ask_curr"])
        next_exit = float(candle["bid_next"]) if trade["side_next"] == "BUY" else float(candle["ask_next"])

        if trade["side_curr"] == "BUY":
            curr_pnl = (curr_exit - trade["curr_entry"]) * trade["qty"]
        else:
            curr_pnl = (trade["curr_entry"] - curr_exit) * trade["qty"]

        if trade["side_next"] == "BUY":
            next_pnl = (next_exit - trade["next_entry"]) * trade["qty"]
        else:
            next_pnl = (trade["next_entry"] - next_exit) * trade["qty"]

        result = {
            **trade,
            "exit_idx": self.current_idx,
            "exit_time": str(candle["datetime"]),
            "exit_gap": float(candle["gap"]),
            "curr_exit": curr_exit,
            "next_exit": next_exit,
            "curr_pnl": round(curr_pnl, 2),
            "next_pnl": round(next_pnl, 2),
            "total_pnl": round(curr_pnl + next_pnl, 2),
        }
        self.closed_trades.append(result)
        return result

    def get_progress(self) -> float:
        if self.gap_df.empty or len(self.gap_df) <= 1:
            return 0.0
        return (self.current_idx / (len(self.gap_df) - 1)) * 100.0

    def total_candles(self) -> int:
        return len(self.gap_df)
